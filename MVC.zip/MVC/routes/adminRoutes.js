// routes/adminRoutes.js
const express = require('express');
const router = express.Router();
const { registerAdmin, authAdmin, getAllFeedback, updateAppointment, addDoctor, getAllDoctors } = require('../controllers/adminController');

router.route('/signup').post(registerAdmin);
router.route('/login').post(authAdmin);
router.route('/feedbacks').get(getAllFeedback);
router.route('/appointments/:appointmentId').put(updateAppointment);
router.route('/adddoctor').post(addDoctor);
router.route('/doctors').get(getAllDoctors);

module.exports = router;
