const mongoose = require('mongoose');

// Define the appointment schema
const appointmentSchema = new mongoose.Schema({
  AppID: { type: Number, unique: true },
  Description: { type: String, required: true },
  Disease: { type: String, required: true },
  DoctID: { type: Number },
  Time: { type: String },
  Status: { type: String },
  Preference: { type: String, required: true },
  Date: { type: String, required: true } // Use date format like '12-01-2001'
}); 

// Pre-save hook to auto-increment AppID
appointmentSchema.pre('save', async function(next) {
  const doc = this;

  if (doc.isNew) {
    try {
      // Find the latest AppID in any patient history
      const lastAppointment = await mongoose.model('PatientHistory').aggregate([
        { $unwind: "$Appointments" },
        { $sort: { "Appointments.AppID": -1 } },
        { $limit: 1 }
      ]);
      const lastAppID = lastAppointment.length > 0 ? lastAppointment[0].Appointments.AppID : 1000;
      doc.AppID = lastAppID + 1;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

// Define the patient history schema
const patientHistorySchema = new mongoose.Schema({
  PID: { type: Number, required: true, unique: true },
  Appointments: { type: [appointmentSchema], required: true }
});

// Create the model from the schema
const PatientHistory = mongoose.model('PatientHistory', patientHistorySchema);

module.exports = PatientHistory;
