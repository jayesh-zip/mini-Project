const mongoose = require('mongoose');

const adminSchema = new mongoose.Schema({
  Aid: { type: Number, unique: true },
  Name: { type: String, required: true },
  Age: { type: Number, required: true },
  Mono: { type: String, required: true },
  Email: { type: String, required: true, unique: true },
  Gender: { type: String, required: true },
  Password: { type: String, required: true },
  CreatedAt: { type: Date, default: Date.now }
});

adminSchema.pre('save', async function(next) {
  const doc = this;
  if (doc.isNew) {
    try {
      const lastAdmin = await mongoose.model('Admin').findOne({}, {}, { sort: { 'Aid': -1 } });
      doc.Aid = lastAdmin ? lastAdmin.Aid + 1 : 1;
    } catch (error) {
      return next(error);
    }
  }
  next();
});

const Admin = mongoose.model('Admin', adminSchema);

module.exports = Admin;
