// controllers/adminController.js
const asyncHandler = require('express-async-handler');
const Admin = require('../models/adminModel');
const Feedback = require('../models/feedbackModel');
const PatientHistory = require('../models/patientHistoryModel');
const Doctor = require('../models/doctorModel');
const generateToken = require('../config/generateToken');

// @desc    Register a new admin
// @route   POST /admin/signup
// @access  Public
const registerAdmin = asyncHandler(async (req, res) => {
  const { Name, Age, Mono, Email, Gender, Password } = req.body;

  if (!Name || !Age || !Mono || !Email || !Gender || !Password) {
    res.status(400);
    throw new Error('Please enter all fields');
  }

  const adminExists = await Admin.findOne({ Email });

  if (adminExists) {
    res.status(400);
    throw new Error('Admin already exists');
  }

  const admin = await Admin.create({
    Name,
    Age,
    Mono,
    Email,
    Gender,
    Password,
  });

  if (admin) {
    res.status(201).json({
      _id: admin._id,
      Name: admin.Name,
      Age: admin.Age,
      Mono: admin.Mono,
      Email: admin.Email,
      Gender: admin.Gender,
      token: generateToken(admin._id),
    });
  } else {
    res.status(400);
    throw new Error('Failed to create the admin');
  }
});

// @desc    Auth admin & get token
// @route   POST /admin/login
// @access  Public
const authAdmin = asyncHandler(async (req, res) => {
  const { Email, Password } = req.body;

  const admin = await Admin.findOne({ Email });

  if (admin && (await admin.matchPassword(Password))) {
    res.json({
      _id: admin._id,
      Name: admin.Name,
      Age: admin.Age,
      Mono: admin.Mono,
      Email: admin.Email,
      Gender: admin.Gender,
      token: generateToken(admin._id),
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
});

// @desc    Fetch all feedbacks
// @route   GET /admin/feedbacks
// @access  Public
const getAllFeedback = asyncHandler(async (req, res) => {
    const feedbacks = await Feedback.find({});
  
    const formattedFeedbacks = feedbacks.map(fb => ({
      name: fb.Name,
      rating: fb.Rating,
      date: new Date(fb.CreatedAt).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      }),
      description: fb.ShortDescription,
    }));
  
    res.json(formattedFeedbacks);
  });


// @desc    Update an appointment
// @route   PUT /admin/appointments/:appointmentId
// @access  Public
const updateAppointment = asyncHandler(async (req, res) => {
    const { appointmentId } = req.params;
    const { status, time, doctorId } = req.body;
  
    if (!['slot1', 'slot2'].includes(time)) {
      res.status(400);
      throw new Error('Invalid time slot');
    }
  
    const patientHistory = await PatientHistory.findOne({
      'Appointments.AppID': appointmentId
    });
  
    if (!patientHistory) {
      res.status(404);
      throw new Error('Appointment not found');
    }
  
    const appointment = patientHistory.Appointments.find(app => app.AppID === parseInt(appointmentId));
  
    if (appointment) {
      appointment.Status = status || appointment.Status;
      appointment.Time = time || appointment.Time;
      appointment.DoctID = doctorId || appointment.DoctID;
  
      await patientHistory.save();
  
      res.json({ message: 'Appointment updated successfully' });
    } else {
      res.status(404);
      throw new Error('Appointment not found');
    }
  });


// @desc    Add a new doctor
// @route   POST /admin/doctors
// @access  Public
const addDoctor = asyncHandler(async (req, res) => {
    const { Name, Gender, Age, Mono, Email, Specialist, Degrees } = req.body;
  
    if (!Name || !Gender || !Age || !Mono || !Email || !Specialist || !Degrees) {
      res.status(400);
      throw new Error('Please provide all required fields');
    }
  
    try {
      const doctor = await Doctor.create({
        Name,
        Gender,
        Age,
        Mono,
        Email,
        Specialist,
        Degrees
      });
  
      res.status(201).json({
        message: 'Doctor added successfully',
        doctor
      });
    } catch (error) {
      res.status(500).json({
        message: 'Failed to add doctor',
        error: error.message
      });
    }
  });


// @desc    Get all doctors' details
// @route   GET /admin/doctors
// @access  Public
const getAllDoctors = asyncHandler(async (req, res) => {
    try {
      const doctors = await Doctor.find({}, 'DID Name Specialist Degrees');
  
      if (!doctors.length) {
        res.status(404);
        throw new Error('No doctors found');
      }
  
      res.json(doctors);
    } catch (error) {
      res.status(500).json({
        message: 'Failed to fetch doctors details',
        error: error.message
      });
    }
  });

module.exports = { registerAdmin, authAdmin, getAllFeedback, updateAppointment, addDoctor, getAllDoctors };
