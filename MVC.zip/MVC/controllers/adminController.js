// controllers/adminController.js
const asyncHandler = require('express-async-handler');
const Patient = require('../models/patientModel')
const Admin = require('../models/adminModel');
const Feedback = require('../models/feedbackModel');
const PatientHistory = require('../models/patientHistoryModel');
const Doctor = require('../models/doctorModel');
const moment = require('moment');
//const generateToken = require('../config/generateToken');


// @desc    Add a new admin
// @route   POST /admin/admins
// @access  Public
const addAdmin = asyncHandler(async (req, res) => {
  const { Name, Age, Mono, Email, Gender, Password } = req.body;

  if (!Name || !Age || !Mono || !Email || !Gender || !Password) {
    res.status(400);
    throw new Error('Please enter all fields');
  }

  const adminExists = await Admin.findOne({ Email });

  if (adminExists) {
    res.status(400);
    throw new Error('Admin already exists');
  }

  const admin = new Admin({
    Name,
    Age,
    Mono,
    Email,
    Gender,
    Password
  });

  try {
    await admin.save();
    res.status(201).json({
      message: 'Admin added successfully',
      admin: {
        Aid: admin.Aid,
        Name: admin.Name,
        Age: admin.Age,
        Mono: admin.Mono,
        Email: admin.Email,
        Gender: admin.Gender
      }
    });
  } catch (error) {
    res.status(500).json({
      message: 'Failed to add admin',
      error: error.message
    });
  }
});



// @desc    Login admin
// @route   POST /admin/login
// @access  Public
const loginAdmin = asyncHandler(async (req, res) => {
  const { Email, Password } = req.body;

  if (!Email || !Password) {
    res.status(400);
    throw new Error('Please enter both email and password');
  }

  const admin = await Admin.findOne({ Email });

  if (admin && admin.Password === Password) {
    res.json({
      message: 'Login successful',
      admin: {
        Aid: admin.Aid,
        Name: admin.Name,
        Age: admin.Age,
        Mono: admin.Mono,
        Email: admin.Email,
        Gender: admin.Gender
      }
    });
  } else {
    res.status(401);
    throw new Error('Invalid email or password');
  }
});


// @desc    Fetch all feedbacks
// @route   GET /admin/feedbacks
// @access  Public
const getAllFeedback = asyncHandler(async (req, res) => {
    const feedbacks = await Feedback.find({});
  
    const formattedFeedbacks = feedbacks.map(fb => ({
      name: fb.Name,
      rating: fb.Rating,
      date: new Date(fb.CreatedAt).toLocaleDateString('en-US', {
        month: 'long',
        day: 'numeric',
        year: 'numeric',
      }),
      description: fb.ShortDescription,
    }));
  
    res.json(formattedFeedbacks);
  });


// @desc    Update an appointment
// @route   PUT /admin/appointments/:appointmentId
// @access  Public
const updateAppointment = asyncHandler(async (req, res) => {
    const { appointmentId } = req.params;
    const { status, time, doctorId } = req.body;
  
    if (!['slot1', 'slot2'].includes(time)) {
      res.status(400);
      throw new Error('Invalid time slot');
    }
  
    const patientHistory = await PatientHistory.findOne({
      'Appointments.AppID': appointmentId
    });
  
    if (!patientHistory) {
      res.status(404);
      throw new Error('Appointment not found');
    }
  
    const appointment = patientHistory.Appointments.find(app => app.AppID === parseInt(appointmentId));
  
    if (appointment) {
      appointment.Status = status || appointment.Status;
      appointment.Time = time || appointment.Time;
      appointment.DoctID = doctorId || appointment.DoctID;
  
      await patientHistory.save();
  
      res.json({ message: 'Appointment updated successfully' });
    } else {
      res.status(404);
      throw new Error('Appointment not found');
    }
  });


// @desc    Add a new doctor
// @route   POST /admin/doctors
// @access  Public
const addDoctor = asyncHandler(async (req, res) => {
    const { Name, Gender, Age, Mono, Email, Specialist, Degrees } = req.body;
  
    if (!Name || !Gender || !Age || !Mono || !Email || !Specialist || !Degrees) {
      res.status(400);
      throw new Error('Please provide all required fields');
    }
  
    try {
      const doctor = await Doctor.create({
        Name,
        Gender,
        Age,
        Mono,
        Email,
        Specialist,
        Degrees
      });
  
      res.status(201).json({
        message: 'Doctor added successfully',
        doctor
      });
    } catch (error) {
      res.status(500).json({
        message: 'Failed to add doctor',
        error: error.message
      });
    }
  });


// @desc    Get all doctors' details
// @route   GET /admin/doctors
// @access  Public
const getAllDoctors = asyncHandler(async (req, res) => {
    try {
      const doctors = await Doctor.find({}, 'DID Name Specialist Degrees');
  
      if (!doctors.length) {
        res.status(404);
        throw new Error('No doctors found');
      }
  
      res.json(doctors);
    } catch (error) {
      res.status(500).json({
        message: 'Failed to fetch doctors details',
        error: error.message
      });
    }
  });



// @desc    Get all appointments with patient name, disease, doctor name, and status
// @route   GET /admin/appointments
// @access  Public
const getAllAppointments = asyncHandler(async (req, res) => {
  try {
      const patientHistories = await PatientHistory.find();
      const appointments = [];

      for (const history of patientHistories) {
          const patient = await Patient.findOne({ PID: history.PID });
          for (const appointment of history.Appointments) {
              const doctor = await Doctor.findOne({ DID: appointment.DoctID });
              appointments.push({
                  Status: appointment.Status,
                  PatientName: patient ? patient.Name : 'Unknown',
                  Disease: appointment.Disease,
                  DoctorName: doctor ? doctor.Name : 'Unknown'
              });
          }
      }

      res.json(appointments);
  } catch (error) {
      res.status(500).json({
          message: 'Failed to fetch appointments',
          error: error.message
      });
  }
});


// @desc    Delete an appointment
// @route   DELETE /admin/deleteAppointment/:appointmentId
// @access  Public
const deleteAppointment = asyncHandler(async (req, res) => {
  const { appointmentId } = req.params;

  try {
    const patientHistory = await PatientHistory.findOne({
      'Appointments.AppID': appointmentId
    });

    if (!patientHistory) {
      res.status(404);
      throw new Error('Appointment not found');
    }

    const appointmentIndex = patientHistory.Appointments.findIndex(
      app => app.AppID === parseInt(appointmentId)
    );

    if (appointmentIndex !== -1) {
      patientHistory.Appointments.splice(appointmentIndex, 1);
      await patientHistory.save();
      res.json({ message: 'Appointment deleted successfully' });
    } else {
      res.status(404);
      throw new Error('Appointment not found');
    }
  } catch (error) {
    res.status(500).json({
      message: 'Failed to delete appointment',
      error: error.message
    });
  }
});


// @desc    Update doctor information
// @route   PUT /admin/updateDoctor/:did
// @access  Public
const updateDoctor = asyncHandler(async (req, res) => {
  const { did } = req.params;
  const { Name, Gender, Age, Mono, Email, Specialist, Degrees } = req.body;

  try {
    const doctor = await Doctor.findOne({ DID: did });

    if (!doctor) {
      res.status(404);
      throw new Error('Doctor not found');
    }

    // Update the doctor information, excluding DID
    if (Name) doctor.Name = Name;
    if (Gender) doctor.Gender = Gender;
    if (Age) doctor.Age = Age;
    if (Mono) doctor.Mono = Mono;
    if (Email) doctor.Email = Email;
    if (Specialist) doctor.Specialist = Specialist;
    if (Degrees) doctor.Degrees = Degrees;

    await doctor.save();

    res.json({ message: 'Doctor updated successfully', doctor });
  } catch (error) {
    res.status(500).json({
      message: 'Failed to update doctor',
      error: error.message
    });
  }
});


// @desc    Delete a doctor
// @route   DELETE /admin/deleteDoctor/:did
// @access  Public
const deleteDoctor = asyncHandler(async (req, res) => {
  const { did } = req.params;

  try {
    const doctor = await Doctor.findOneAndDelete({ DID: did });

    if (!doctor) {
      res.status(404);
      throw new Error('Doctor not found');
    }

    res.json({ message: 'Doctor deleted successfully' });
  } catch (error) {
    res.status(500).json({
      message: 'Failed to delete doctor',
      error: error.message
    });
  }
});


// @desc    Fetch all admins
// @route   GET /admin/admins
// @access  Public
const getAllAdmins = asyncHandler(async (req, res) => {
  try {
    const admins = await Admin.find({}, 'Aid Name Age Mono Email Gender');

    if (!admins.length) {
      res.status(404);
      throw new Error('No admins found');
    }

    res.json(admins);
  } catch (error) {
    res.status(500).json({
      message: 'Failed to fetch admins',
      error: error.message
    });
  }
});



// @desc    Update admin information
// @route   PUT /admin/admins/:adminId
// @access  Public
const updateAdmin = asyncHandler(async (req, res) => {
  const { adminId } = req.params;
  const { Name, Age, Mono, Email, Gender, Password } = req.body;

  try {
    // Find the admin by adminId
    const admin = await Admin.findOne({ Aid: adminId });

    if (!admin) {
      res.status(404);
      throw new Error('Admin not found');
    }

    // Update fields except Aid
    if (Name !== undefined) admin.Name = Name;
    if (Age !== undefined) admin.Age = Age;
    if (Mono !== undefined) admin.Mono = Mono;
    if (Email !== undefined) admin.Email = Email;
    if (Gender !== undefined) admin.Gender = Gender;

    // If password is provided, store it as plain text
    if (Password !== undefined) {
      admin.Password = Password; // Store password as plain text
    }

    // Save the updated admin
    await admin.save();

    res.json({
      message: 'Admin updated successfully',
      admin: {
        Aid: admin.Aid,
        Name: admin.Name,
        Age: admin.Age,
        Mono: admin.Mono,
        Email: admin.Email,
        Gender: admin.Gender
      }
    });
  } catch (error) {
    res.status(500).json({
      message: 'Failed to update admin',
      error: error.message
    });
  }
});



// @desc    Delete an admin
// @route   DELETE /admin/admins/:adminId
// @access  Public
const deleteAdmin = asyncHandler(async (req, res) => {
  const { adminId } = req.params;

  try {
    const admin = await Admin.findOneAndDelete({ Aid: adminId });

    if (!admin) {
      res.status(404);
      throw new Error('Admin not found');
    }

    res.json({ message: 'Admin deleted successfully' });
  } catch (error) {
    res.status(500).json({
      message: 'Failed to delete admin',
      error: error.message
    });
  }
});



// @desc    Get counts of today's patients with "complete" or "confirm" status by disease type
// @route   GET /api/patients/status-counts
// @access  Public
const getStatusCounts = asyncHandler(async (req, res) => {
  const diseaseTypes = [
    'Gastroenterologist',
    'Psychiatrist',
    'Oncologist',
    'Pediatricians',
    'Cardiologist',
    'Neurologist',
    'Dermatologist',
    'Endocrinologist',
    'Rheumatologist',
    'Other'
  ];

  // Initialize the counts object
  const counts = diseaseTypes.reduce((acc, disease) => {
    acc[disease] = 0;
    return acc;
  }, {});

  // Get today's date in the required format
  const today = moment().format('DD-MM-YYYY');

  // Fetch all patient histories
  const patientHistories = await PatientHistory.find({});

  // Filter appointments with today's date and "complete" or "confirm" status, then count them by disease type
  patientHistories.forEach(history => {
    history.Appointments.forEach(appointment => {
      if (appointment.Date === today && (appointment.Status === 'complete' || appointment.Status === 'confirm')) {
        counts[appointment.Disease] = (counts[appointment.Disease] || 0) + 1;
      }
    });
  });

  res.json(counts);
});




// @desc    Get counts of patients by date for the past week (Monday to Saturday)
// @route   GET /api/patients/weekly-counts
// @access  Public
const getWeeklyCounts = asyncHandler(async (req, res) => {
  const today = moment();
  const dayOfWeek = today.isoWeekday(); // 1 (Monday) to 7 (Sunday)

  // Calculate the start date (last Monday) and end date (last Saturday)
  const startDate = today.clone().subtract(dayOfWeek + 6, 'days').startOf('day');
  const endDate = startDate.clone().add(6, 'days').endOf('day');

  // Print all dates from last Monday to last Saturday
  for (let i = 0; i < 6; i++) {
    startDate.clone().add(i, 'days').format('DD-MM-YYYY')
  }

  // Initialize the counts object
  const counts = {
    monday: 0,
    tuesday: 0,
    wednesday: 0,
    thursday: 0,
    friday: 0,
    saturday: 0
  };

  // Fetch all patient histories
  const patientHistories = await PatientHistory.find({});

  // Count appointments by date excluding "waiting" status
  patientHistories.forEach(history => {
    history.Appointments.forEach(appointment => {
      const appointmentDate = moment(appointment.Date, 'DD-MM-YYYY').startOf('day');
      if (appointmentDate.isBetween(startDate, endDate, null, '[]') && appointment.Status !== 'waiting') {
        const dayName = appointmentDate.format('dddd').toLowerCase();
        counts[dayName]++;
      }
    });
  });

  res.json(counts);
});




const getDoctorAvailability = asyncHandler(async (req, res) => {
  // Use moment to get the current date in "DD-MM-YYYY" format
  // const date = moment().format('DD-MM-YYYY');
  const date = "29-07-2024"
  console.log('Current Date:', date);

  // Get all doctors
  const doctors = await Doctor.find({});
  console.log('Doctors:', doctors);

  // Initialize availability data
  const availability = [];

  for (const doctor of doctors) {
    // Fetch appointments for the doctor on the given date
    const patientHistories = await PatientHistory.find({
      'Appointments.DoctID': doctor.DID,
      'Appointments.Date': date,
    });
    console.log(`Patient Histories for Doctor ID ${doctor.DID}:`, patientHistories);

    let slot1Count = 0;
    let slot2Count = 0;

    patientHistories.forEach(history => {
      history.Appointments.forEach(appointment => {
        if (appointment.DoctID === doctor.DID && appointment.Date === date) {
          if (appointment.Time === 'slot1') {
            slot1Count++;
          } else if (appointment.Time === 'slot2') {
            slot2Count++;
          }
        }
      });
    });

    console.log(`Slot 1 Count for Doctor ID ${doctor.DID}:`, slot1Count);
    console.log(`Slot 2 Count for Doctor ID ${doctor.DID}:`, slot2Count);

    availability.push({
      doctorName: doctor.Name,
      doctorDegree: doctor.Degrees.join(', '),
      doctorSpeciality: doctor.Specialist,
      slot1: slot1Count >= 20 ? 'not available' : `${20 - slot1Count} available`,
      slot2: slot2Count >= 20 ? 'not available' : `${20 - slot2Count} available`
    });
  }

  res.json(availability);
});





module.exports = { addAdmin, loginAdmin, getAllFeedback, updateAppointment, addDoctor, getAllDoctors, getAllAppointments, deleteAppointment, updateDoctor, deleteDoctor, getAllAdmins, updateAdmin, deleteAdmin, getStatusCounts, getWeeklyCounts, getDoctorAvailability };
